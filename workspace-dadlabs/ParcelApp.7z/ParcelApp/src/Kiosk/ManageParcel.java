package Kiosk;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Panel;
import java.awt.Color;

public class ManageParcel extends JFrame {


	private static final long serialVersionUID = 1L;
	
	private JPanel contentPane;
	private JTextField tfParcelWeight;
	private JTextField tfSenderName;
	private JTextField tfSenderAddress;
	private JTextField tfSenderPhone;
	private JTextField tfReceiverName;
	private JTextField tfReceiverAddress;
	private JTextField tfReceiverPhone;
	private final ButtonGroup receiverLocation = new ButtonGroup();
	private JTextField textField_10;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					parceldetails frame = new parceldetails();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public ManageParcel() {
		
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1553, 1246);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblTitle = new JLabel("Fill In Parcel Information");
		lblTitle.setFont(new Font("Tahoma", Font.BOLD, 27));
		lblTitle.setBounds(42, 11, 520, 40);
		contentPane.add(lblTitle);
		
		JLabel lblParcelWeight = new JLabel("Parcel Weight");
		lblParcelWeight.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblParcelWeight.setBounds(42, 111, 187, 40);
		contentPane.add(lblParcelWeight);
		
		JLabel lblSenderName = new JLabel("Sender Name");
		lblSenderName.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblSenderName.setBounds(42, 213, 187, 40);
		contentPane.add(lblSenderName);
		
		JLabel lblSenderAddress = new JLabel("Sender Address");
		lblSenderAddress.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblSenderAddress.setBounds(42, 259, 187, 40);
		contentPane.add(lblSenderAddress);
		
		JLabel lblParcelType = new JLabel("Parcel Type");
		lblParcelType.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblParcelType.setBounds(42, 162, 187, 40);
		contentPane.add(lblParcelType);
		
		JLabel lblReceiverName = new JLabel("Receiver Name");
		lblReceiverName.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblReceiverName.setBounds(42, 351, 187, 40);
		contentPane.add(lblReceiverName);
		
		JLabel lblReceiverAddress = new JLabel("Receiver Address");
		lblReceiverAddress.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblReceiverAddress.setBounds(42, 399, 187, 40);
		contentPane.add(lblReceiverAddress);
		
		JLabel lblSenderPhoneNumber = new JLabel("Sender Phone Number");
		lblSenderPhoneNumber.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblSenderPhoneNumber.setBounds(42, 310, 239, 40);
		contentPane.add(lblSenderPhoneNumber);
		
		JLabel lblReceiverPhoneNumber = new JLabel("Receiver Phone Number");
		lblReceiverPhoneNumber.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblReceiverPhoneNumber.setBounds(42, 447, 239, 40);
		contentPane.add(lblReceiverPhoneNumber);
		
		JLabel lblReceiverLocation = new JLabel("Receiver Location");
		lblReceiverLocation.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblReceiverLocation.setBounds(42, 494, 239, 40);
		contentPane.add(lblReceiverLocation);
		
		JRadioButton rdbtnState = new JRadioButton("State");
		receiverLocation.add(rdbtnState);
		rdbtnState.setFont(new Font("Tahoma", Font.PLAIN, 20));
		rdbtnState.setBounds(284, 495, 210, 38);
		contentPane.add(rdbtnState);
		
		JRadioButton rdbtnPeninsular = new JRadioButton("Peninsular");
		receiverLocation.add(rdbtnPeninsular);
		rdbtnPeninsular.setFont(new Font("Tahoma", Font.PLAIN, 20));
		rdbtnPeninsular.setBounds(282, 540, 210, 38);
		contentPane.add(rdbtnPeninsular);
		
		JRadioButton rdbtnSabahsarawak = new JRadioButton("Sabah/Sarawak");
		receiverLocation.add(rdbtnSabahsarawak);
		rdbtnSabahsarawak.setFont(new Font("Tahoma", Font.PLAIN, 20));
		rdbtnSabahsarawak.setBounds(281, 585, 210, 38);
		contentPane.add(rdbtnSabahsarawak);
		
		tfParcelWeight = new JTextField();
		tfParcelWeight.setEditable(false);
		tfParcelWeight.setFont(new Font("Tahoma", Font.PLAIN, 20));
		tfParcelWeight.setBounds(284, 118, 466, 33);
		contentPane.add(tfParcelWeight);
		tfParcelWeight.setColumns(10);
		
		//Random number
		double random = Math.floor(Math.random() * (1000 - 0) + 0) / 100;
		String pweight = String.valueOf(random);
		tfParcelWeight.setText(pweight + " KG");
		
		tfSenderName = new JTextField();
		tfSenderName.setFont(new Font("Tahoma", Font.PLAIN, 20));
		tfSenderName.setColumns(10);
		tfSenderName.setBounds(284, 217, 466, 33);
		contentPane.add(tfSenderName);
		
		tfSenderAddress = new JTextField();
		tfSenderAddress.setFont(new Font("Tahoma", Font.PLAIN, 20));
		tfSenderAddress.setColumns(10);
		tfSenderAddress.setBounds(284, 263, 466, 33);
		contentPane.add(tfSenderAddress);
		
		String t1[] = { "Standard", "Fragile", "Religious"};
		JComboBox cbParcelType = new JComboBox(t1); 
		cbParcelType.setFont(new Font("Tahoma", Font.PLAIN, 20));
		cbParcelType.setBounds(284, 169, 466, 27);
		contentPane.add(cbParcelType);
		
		tfSenderPhone = new JTextField();
		tfSenderPhone.setFont(new Font("Tahoma", Font.PLAIN, 20));
		tfSenderPhone.setColumns(10);
		tfSenderPhone.setBounds(284, 310, 466, 33);
		contentPane.add(tfSenderPhone);
		
		tfReceiverName = new JTextField();
		tfReceiverName.setFont(new Font("Tahoma", Font.PLAIN, 20));
		tfReceiverName.setColumns(10);
		tfReceiverName.setBounds(284, 355, 466, 33);
		contentPane.add(tfReceiverName);
		
		tfReceiverAddress = new JTextField();
		tfReceiverAddress.setFont(new Font("Tahoma", Font.PLAIN, 20));
		tfReceiverAddress.setColumns(10);
		tfReceiverAddress.setBounds(284, 403, 466, 33);
		contentPane.add(tfReceiverAddress);
		
		tfReceiverPhone = new JTextField();
		tfReceiverPhone.setFont(new Font("Tahoma", Font.PLAIN, 20));
		tfReceiverPhone.setColumns(10);
		tfReceiverPhone.setBounds(284, 451, 466, 33);
		contentPane.add(tfReceiverPhone);
		
		JButton btnSubmit = new JButton("Submit");
		btnSubmit.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnSubmit.setBounds(1354, 1073, 141, 64);
		contentPane.add(btnSubmit);
		
		JButton btnReset = new JButton("Reset");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{				
				cbParcelType.setSelectedIndex(0);
				tfSenderName.setText(null);
				tfSenderAddress.setText(null);
				tfSenderPhone.setText(null);
				tfReceiverName.setText(null);
				tfReceiverAddress.setText(null);
				tfReceiverPhone.setText(null);
			}
		});
		btnReset.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnReset.setBounds(1181, 1073, 141, 64);
		contentPane.add(btnReset);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				dispose();
				ParcelKiosk ParcelKiosk;
				try {
					ParcelKiosk = new ParcelKiosk();
					ParcelKiosk.setVisible(true);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		btnBack.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnBack.setBounds(42, 1073, 141, 64);
		contentPane.add(btnBack);
		
		Panel panel = new Panel();
		panel.setBackground(Color.LIGHT_GRAY);
		panel.setBounds(35, 677, 1494, 366);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Parcel Delivery Details");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel.setBounds(10, 11, 278, 31);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Sender Name");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(23, 75, 142, 25);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Sender Address");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_1_1.setBounds(23, 143, 142, 25);
		panel.add(lblNewLabel_1_1);
		
		JLabel lblSenderPhoneNumber_1 = new JLabel("Sender Phone Number");
		lblSenderPhoneNumber_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblSenderPhoneNumber_1.setBounds(23, 204, 220, 40);
		panel.add(lblSenderPhoneNumber_1);
		
		JLabel lblReceiverName_1 = new JLabel("Receiver Name");
		lblReceiverName_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblReceiverName_1.setBounds(755, 67, 187, 40);
		panel.add(lblReceiverName_1);
		
		JLabel lblReceiverAddress_1 = new JLabel("Receiver Address");
		lblReceiverAddress_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblReceiverAddress_1.setBounds(755, 135, 187, 40);
		panel.add(lblReceiverAddress_1);
		
		JLabel lblReceiverPhoneNumber_1 = new JLabel("Receiver Phone Number");
		lblReceiverPhoneNumber_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblReceiverPhoneNumber_1.setBounds(755, 204, 230, 40);
		panel.add(lblReceiverPhoneNumber_1);
		
		JLabel lblReceiverLocation_1 = new JLabel("Receiver Location");
		lblReceiverLocation_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblReceiverLocation_1.setBounds(755, 272, 220, 40);
		panel.add(lblReceiverLocation_1);
		
		JLabel lblNewLabel_4 = new JLabel(" :");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_4.setBounds(246, 76, 32, 23);
		panel.add(lblNewLabel_4);
		
		JLabel lblNewLabel_4_1 = new JLabel(" :");
		lblNewLabel_4_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_4_1.setBounds(246, 145, 32, 23);
		panel.add(lblNewLabel_4_1);
		
		JLabel lblNewLabel_4_2 = new JLabel(" :");
		lblNewLabel_4_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_4_2.setBounds(246, 213, 32, 23);
		panel.add(lblNewLabel_4_2);
		
		JLabel lblNewLabel_4_3 = new JLabel(" :");
		lblNewLabel_4_3.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_4_3.setBounds(983, 77, 32, 23);
		panel.add(lblNewLabel_4_3);
		
		JLabel lblNewLabel_4_4 = new JLabel(" :");
		lblNewLabel_4_4.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_4_4.setBounds(983, 145, 32, 23);
		panel.add(lblNewLabel_4_4);
		
		JLabel lblNewLabel_4_5 = new JLabel(" :");
		lblNewLabel_4_5.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_4_5.setBounds(983, 213, 32, 23);
		panel.add(lblNewLabel_4_5);
		
		JLabel lblNewLabel_4_6 = new JLabel(" :");
		lblNewLabel_4_6.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_4_6.setBounds(983, 281, 32, 23);
		panel.add(lblNewLabel_4_6);
		
		Panel panel_1 = new Panel();
		panel_1.setBackground(Color.LIGHT_GRAY);
		panel_1.setBounds(817, 296, 697, 326);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("Parcel Info");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_2.setBounds(10, 11, 193, 43);
		panel_1.add(lblNewLabel_2);
		
		JLabel lblParcelId = new JLabel("Parcel ID");
		lblParcelId.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblParcelId.setBounds(10, 76, 133, 40);
		panel_1.add(lblParcelId);
		
		JLabel lblParcelWeight_1 = new JLabel("Parcel Weight");
		lblParcelWeight_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblParcelWeight_1.setBounds(10, 156, 140, 40);
		panel_1.add(lblParcelWeight_1);
		
		JLabel lblParcelType_1 = new JLabel("Parcel Type");
		lblParcelType_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblParcelType_1.setBounds(10, 237, 133, 40);
		panel_1.add(lblParcelType_1);
		
		JLabel lblNewLabel_4_7 = new JLabel(" :");
		lblNewLabel_4_7.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_4_7.setBounds(153, 85, 32, 23);
		panel_1.add(lblNewLabel_4_7);
		
		JLabel lblNewLabel_4_8 = new JLabel(" :");
		lblNewLabel_4_8.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_4_8.setBounds(153, 165, 32, 23);
		panel_1.add(lblNewLabel_4_8);
		
		JLabel lblNewLabel_4_9 = new JLabel(" :");
		lblNewLabel_4_9.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_4_9.setBounds(153, 246, 32, 23);
		panel_1.add(lblNewLabel_4_9);
		
		JLabel lblNewLabel_3 = new JLabel("Total Price :");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 22));
		lblNewLabel_3.setBounds(817, 47, 187, 54);
		contentPane.add(lblNewLabel_3);
		
		textField_10 = new JTextField();
		textField_10.setEditable(false);
		textField_10.setBounds(954, 69, 544, 184);
		contentPane.add(textField_10);
		textField_10.setColumns(10);
	}
}
