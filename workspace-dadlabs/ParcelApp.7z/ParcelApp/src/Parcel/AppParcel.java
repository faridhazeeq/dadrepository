package Parcel;

import java.io.Serializable;

public class AppParcel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public int parcelID;
	public double parcwht;
	public String parcno;
	public String parctype;
	public int orderID;
	public String parcdlrate;
	public String paymentID;
	public String parccont;
	
	public AppParcel() {
		
	}

	public AppParcel(double parcwht, String parcno, String parctype, int orderID, String parcdlrate, String paymentID,
			String parccont) {
		this.parcwht = parcwht;
		this.parcno = parcno;
		this.parctype = parctype;
		this.orderID = orderID;
		this.parcdlrate = parcdlrate;
		this.paymentID = paymentID;
		this.parccont = parccont;
	}



	public int getParcelID() {
		return parcelID;
	}

	public void setParcelID(int parcelID) {
		this.parcelID = parcelID;
	}

	public double getParcwht() {
		return parcwht;
	}

	public void setParcwht(double parcwht) {
		this.parcwht = parcwht;
	}

	public String getParcno() {
		return parcno;
	}

	public void setParcno(String parcno) {
		this.parcno = parcno;
	}

	public String getParctype() {
		return parctype;
	}

	public void setParctype(String parctype) {
		this.parctype = parctype;
	}

	public int getOrderID() {
		return orderID;
	}

	public void setOrderID(int orderID) {
		this.orderID = orderID;
	}

	public String getParcdlrate() {
		return parcdlrate;
	}

	public void setParcdlrate(String parcdlrate) {
		this.parcdlrate = parcdlrate;
	}

	public String getPaymentID() {
		return paymentID;
	}

	public void setPaymentID(String paymentID) {
		this.paymentID = paymentID;
	}

	public String getParccont() {
		return parccont;
	}

	public void setParccont(String parccont) {
		this.parccont = parccont;
	}
	
	
}
