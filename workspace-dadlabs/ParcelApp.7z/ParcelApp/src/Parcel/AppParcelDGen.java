package Parcel;

public class AppParcelDGen {

	static int i =1;
	AppParcel parcel = new AppParcel();
	
	public String getParcelID() {
		
		String parcelID = "1000" + i++;;
		
		return parcelID;
		
	}
}
