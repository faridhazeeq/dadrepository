package Transaction;

import java.util.Date;

import Parcel.AppParcel;

public class AppTransactionManager {
	
	AppParcel parcel = new AppParcel();
	
	public AppTransaction addPayment (AppTransaction parcelTransaction)
	{
		int paymentID = parcelTransaction.getTransID();
		parcelTransaction.setTransID(paymentID);
		
		String date = new Date().toString();
		parcelTransaction.setTransdate(date);
		
		String totalAmountCharged = parcelTransaction.getTransamount();
		parcelTransaction.setTransamount(totalAmountCharged);
		
		String creditcard = parcelTransaction.getCc();
		parcelTransaction.setCc(creditcard);
		
		int cvv = parcelTransaction.getCvv();
		parcelTransaction.setCvv(cvv);
		
		String trackNo = parcel.getParcno();
		parcel.setParcno(trackNo);
		
		return parcelTransaction;
		
	}

}
