package Customer;

import java.io.Serializable;

public class appCustomer implements Serializable {
	private static final long serialVersionUID = 1L;
	public int idcust;
	public String sndname;
	public String sndadd;
	public String sndno;
	public String sndsf;
	
	public appCustomer() {
	}
	
	public appCustomer(int idcust, String sndname, String sndadd, String sndno, String sndsf ) {
	    this.idcust = idcust;
	    this.sndname = sndname;
	    this.sndadd = sndadd;
	    this.sndno = sndno;
	    this.sndsf = sndsf;
	  }

	public int getIdcust() {
		return idcust;
	}

	public void setIdcust(int idcust) {
		this.idcust = idcust;
	}

	public String getSndname() {
		return sndname;
	}

	public void setSndname(String sndname) {
		this.sndname = sndname;
	}

	public String getSndadd() {
		return sndadd;
	}

	public void setSndadd(String sndadd) {
		this.sndadd = sndadd;
	}

	public String getSndno() {
		return sndno;
	}

	public void setSndno(String sndno) {
		this.sndno = sndno;
	}

	public String getSndsf() {
		return sndsf;
	}

	public void setSndsf(String sndsf) {
		this.sndsf = sndsf;
	}
	
	
}
