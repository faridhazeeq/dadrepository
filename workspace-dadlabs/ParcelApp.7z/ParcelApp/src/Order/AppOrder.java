package Order;

import java.io.Serializable;

public class AppOrder implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public int orderID;
	public String orderno;
	public String ordedate;
	public String recname;
	public String recadd;
	public String recno;
	public String ordstat;
	public String invno;
	public String ordst;
	
	public AppOrder() {
	}

	public int getOrderID() {
		return orderID;
	}

	public void setOrderID(int orderID) {
		this.orderID = orderID;
	}

	public String getOrderno() {
		return orderno;
	}

	public void setOrderno(String orderno) {
		this.orderno = orderno;
	}

	public String getOrdedate() {
		return ordedate;
	}

	public void setOrdedate(String ordedate) {
		this.ordedate = ordedate;
	}

	public String getRecname() {
		return recname;
	}

	public void setRecname(String recname) {
		this.recname = recname;
	}

	public String getRecadd() {
		return recadd;
	}

	public void setRecadd(String recadd) {
		this.recadd = recadd;
	}

	public String getRecno() {
		return recno;
	}

	public void setRecno(String recno) {
		this.recno = recno;
	}

	public String getOrdstat() {
		return ordstat;
	}

	public void setOrdstat(String ordstat) {
		this.ordstat = ordstat;
	}

	public String getInvno() {
		return invno;
	}

	public void setInvno(String invno) {
		this.invno = invno;
	}

	public String getOrdst() {
		return ordst;
	}

	public void setOrdst(String ordst) {
		this.ordst = ordst;
	}
	
	
}
