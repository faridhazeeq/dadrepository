package TransFrame;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Panel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.border.TitledBorder;
import javax.swing.border.MatteBorder;
import java.awt.Color;
import java.awt.Button;

public class PaymentFrame extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PaymentFrame frame = new PaymentFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public PaymentFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 911, 689);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Parcel Ordering System");
		lblNewLabel.setBounds(332, 11, 227, 25);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		contentPane.add(lblNewLabel);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(10, 47, 877, 594);
		contentPane.add(tabbedPane);
		
		JPanel panel = new JPanel();
		tabbedPane.addTab("Payment ", null, panel, null);
		panel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Card Number");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1.setBounds(10, 11, 231, 14);
		panel.add(lblNewLabel_1);
		
		textField = new JTextField();
		textField.setBounds(10, 36, 852, 33);
		panel.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_1_1 = new JLabel("Valid Through");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1_1.setBounds(10, 149, 231, 22);
		panel.add(lblNewLabel_1_1);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setFont(new Font("Tahoma", Font.PLAIN, 20));
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Year", "2022", "2023", "2024", "2025", "2026", "2027", "2028", "2029", "2030"}));
		comboBox.setSelectedIndex(0);
		comboBox.setBounds(146, 182, 105, 33);
		panel.add(comboBox);
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"Month", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"}));
		comboBox_1.setSelectedIndex(0);
		comboBox_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		comboBox_1.setBounds(10, 182, 105, 33);
		panel.add(comboBox_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("Name On Card");
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1_2.setBounds(10, 80, 231, 14);
		panel.add(lblNewLabel_1_2);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(10, 105, 852, 33);
		panel.add(textField_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("CVV Number");
		lblNewLabel_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1_1_1.setBounds(363, 156, 231, 22);
		panel.add(lblNewLabel_1_1_1);
		
		textField_2 = new JTextField();
		textField_2.setBounds(362, 186, 500, 33);
		panel.add(textField_2);
		textField_2.setColumns(10);
		
		JLabel lblNewLabel_1_2_1 = new JLabel("Total Amount");
		lblNewLabel_1_2_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1_2_1.setBounds(10, 231, 231, 14);
		panel.add(lblNewLabel_1_2_1);
		
		textField_3 = new JTextField();
		textField_3.setEditable(false);
		textField_3.setColumns(10);
		textField_3.setBounds(10, 256, 852, 33);
		panel.add(textField_3);
		
		JButton btnNewButton = new JButton("Proceed");
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnNewButton.setBounds(694, 497, 168, 58);
		panel.add(btnNewButton);
		
		JButton btnBack = new JButton("Back");
		btnBack.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnBack.setBounds(10, 497, 168, 58);
		panel.add(btnBack);
		
		JPanel panel_1 = new JPanel();
		tabbedPane.addTab("Reciept", null, panel_1, null);
		panel_1.setLayout(null);
		
		JLabel lblTransactionStatus = new JLabel("Transaction Status");
		lblTransactionStatus.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblTransactionStatus.setBounds(299, 11, 301, 33);
		panel_1.add(lblTransactionStatus);
		
		JLabel lblStatus = new JLabel("Status");
		lblStatus.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblStatus.setBounds(10, 77, 154, 33);
		panel_1.add(lblStatus);
		
		JLabel lblDatetime = new JLabel("Date/Time");
		lblDatetime.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblDatetime.setBounds(10, 114, 193, 33);
		panel_1.add(lblDatetime);
		
		JLabel lblReferenceNumber = new JLabel("Reference Number");
		lblReferenceNumber.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblReferenceNumber.setBounds(10, 152, 193, 33);
		panel_1.add(lblReferenceNumber);
		
		JLabel lblPaymentAmount = new JLabel("Payment Amount");
		lblPaymentAmount.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblPaymentAmount.setBounds(10, 184, 193, 33);
		panel_1.add(lblPaymentAmount);
		
		JLabel lblBank = new JLabel("Bank");
		lblBank.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblBank.setBounds(10, 220, 193, 33);
		panel_1.add(lblBank);
		
		JLabel lblDeliveryInfo = new JLabel("Delivery Info");
		lblDeliveryInfo.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblDeliveryInfo.setBounds(299, 234, 181, 33);
		panel_1.add(lblDeliveryInfo);
		
		JLabel lblTrackingNumber_1 = new JLabel("Tracking Number");
		lblTrackingNumber_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTrackingNumber_1.setBounds(10, 303, 193, 33);
		panel_1.add(lblTrackingNumber_1);
		
		JButton btnNewButton_1 = new JButton("Print");
		btnNewButton_1.setBounds(10, 507, 852, 48);
		panel_1.add(btnNewButton_1);
		
		JLabel lblNewLabel_2 = new JLabel(" :");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_2.setBounds(192, 77, 38, 33);
		panel_1.add(lblNewLabel_2);
		
		JLabel lblNewLabel_2_1 = new JLabel(" :");
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_2_1.setBounds(192, 114, 38, 33);
		panel_1.add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_2_2 = new JLabel(" :");
		lblNewLabel_2_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_2_2.setBounds(192, 152, 38, 33);
		panel_1.add(lblNewLabel_2_2);
		
		JLabel lblNewLabel_2_3 = new JLabel(" :");
		lblNewLabel_2_3.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_2_3.setBounds(192, 184, 38, 33);
		panel_1.add(lblNewLabel_2_3);
		
		JLabel lblNewLabel_2_4 = new JLabel(" :");
		lblNewLabel_2_4.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_2_4.setBounds(192, 220, 38, 33);
		panel_1.add(lblNewLabel_2_4);
		
		JLabel lblNewLabel_2_5 = new JLabel(" :");
		lblNewLabel_2_5.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_2_5.setBounds(192, 303, 38, 33);
		panel_1.add(lblNewLabel_2_5);
	}
}
