package TransFrame;

import java.text.DecimalFormat;

import Order.AppOrder;
import Parcel.AppParcel;
import Transaction.AppTransaction;


public class Receipt {

	public static String receiptPayment(AppTransaction parcelTransaction) {
		
		DecimalFormat deci = new DecimalFormat("0.00");
		
		AppOrder order = parcelTransaction.getOrder();
		AppParcel parcel = new AppParcel();
		
		String rec = "\n " + "      PARCEL APP SYSTEM              \n"
				+ "------------------------------------------------\n"
				+ "                  RECEIPT    \n"
				+ "------------------------------------------------\n"
				+ "        TRANSACTION STATUS: SUCCESSFULL         \n"
				+ "------------------------------------------------\n"
				+ "DATE: " + parcelTransaction.getTransdate().formatted("dd-MM-YYYY") + "\t" + "References No: " + parcelTransaction.getRefNo() + "\n"
				+ "------------------------------------------------\n"
				+ "PAYMENT ID: " + parcelTransaction.getTransID() + "\n" 
				+ "------------------------------------------------\n"
				+ "TOTAL AMOUNT: "+ parcelTransaction.getTransamount() +"\n"
				+ "------------------------------------------------\n"
				+ "------------------------------------------------\n";
		return rec;
		
	}
}
