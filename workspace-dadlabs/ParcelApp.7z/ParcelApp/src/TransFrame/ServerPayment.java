package TransFrame;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.ResultSet;

import Customer.appCustomer;
import Order.AppOrder;
import Parcel.AppParcel;
import Parcel.AppParcelMnger;
import Transaction.AppTransaction;
import Transaction.AppTransactionManager;

public class ServerPayment extends Thread{

	ObjectOutputStream out =null;

    static String databaseName = "";
	static String username = "";
	static String password = "";
    static Connection conn = null;
    static java.sql.Statement stmt = null;
    static ResultSet rs;
    static String connectionPath = "jdbc:mysql://localhost:3306/" + databaseName + "?" +
            "user=" + username + "&password=" + password;
    
    appCustomer cust = null;
    AppOrder order = null;
    AppParcel parcel = null;
    AppTransaction parcelTransaction = null;
    
    public static void main(String[] args) {
    	
    	AppParcelMnger parcelManager = new AppParcelMnger();
    	AppTransactionManager TransManager = new AppTransactionManager();
    	
    	ServerPaymentFrame paymentFrame = new ServerPaymentFrame();
    	paymentFrame.setVisible(true);
    	
    	try {
			
			
			int portNo = 4884;
			ServerSocket serverSocket = new ServerSocket(portNo);

			int totalReq = 0;
			
			while(true) {
				
				Socket clientSocket = serverSocket.accept();
				
				ObjectInputStream inputStream = new ObjectInputStream(clientSocket.getInputStream()); 

				AppTransaction parceltransaction = (AppTransaction) inputStream.readObject();
				
				parceltransaction = TransManager.addPayment(parceltransaction);
				
				String ccNo = parceltransaction.getCc();
				int paymentID = parceltransaction.getTransID();
				String total = parceltransaction.getTransamount();
				
				
				ObjectOutputStream outputStream = new ObjectOutputStream(clientSocket.getOutputStream());
				outputStream.writeObject(parceltransaction);


				paymentFrame.updateRequestStatus(
						"Payment ID: " + paymentID);
				paymentFrame.updateRequestStatus(
						"Credit Card Registered: " + ccNo);
				paymentFrame.updateRequestStatus(
						"Total: RM " + total);
				paymentFrame.updateRequestStatus(
						"Success!");
				paymentFrame.updateRequestStatus("Accepted connection to from the "
						+ "client. Total request = " + ++totalReq );
				
				System.out.println(ccNo);
				
				outputStream.flush();
				clientSocket.close();	
				inputStream.close();
				outputStream.close();
				
				}
			
			}catch (Exception exception) {
				
				System.out.println("Error!");
				exception.printStackTrace();
			}
			
	}


}