package Kiosk;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Customer.appCustomer;
import Order.AppOrder;
import Parcel.AppParcel;
import Parcel.AppParcelDGen;
import Parcel.AppParcelMnger;
import TransFrame.PaymentFrame;
import Transaction.AppTransaction;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.EventQueue;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Random;
import java.util.Vector;
import java.awt.event.ActionEvent;
import java.awt.Panel;
import java.awt.Color;
import javax.swing.DefaultComboBoxModel;
import java.awt.Button;

public class ManageParcel extends JFrame {

	
	String databaseName = "parceldad";
	String username = "root";
	String password = "123456";
    Connection conn;
    java.sql.Statement stmt;
    ResultSet st;
    String connectionPath = "jdbc:mysql://localhost:3306/" + databaseName + "?" +
            "user=" + username + "&password=" + password;
    
	private static final long serialVersionUID = 1L;
	
	private JPanel contentPane;
	private JTextField tfParcelWeight;
	public static JTextField tfPrice;
	private JTextField tfSenderName;
	private JTextField tfSenderAddress;
	private JTextField tfSenderPhone;
	private JTextField tfReceiverName;
	private JTextField tfReceiverAddress;
	private JTextField tfReceiverPhone;
	Vector records;
	String str;
	JLabel lblParcelID_2;
	
	appCustomer cust = new appCustomer();
	AppOrder order = new AppOrder();
	AppParcel parcel = new AppParcel();
	AppParcelMnger pmng = new AppParcelMnger();
	AppParcelDGen parcelIDGen = new AppParcelDGen();
	AppTransaction parcelTrans = new AppTransaction();
	
	public static void main(String[] args) throws UnknownHostException, 
	IOException {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ManageParcel frame = new ManageParcel();
					frame.setSize(700,600);
					frame.setLocationRelativeTo(null);
					frame.setVisible(true);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public ManageParcel() {
		
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1553, 1246);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblTitle = new JLabel("Fill In Parcel Information");
		lblTitle.setFont(new Font("Tahoma", Font.BOLD, 27));
		lblTitle.setBounds(42, 18, 520, 40);
		contentPane.add(lblTitle);
		
		//Random number
		double random = Math.floor(Math.random() * (1000 - 0) + 0) / 100;
		String pweight = String.valueOf(random);
		
		String t1[] = { "Standard", "Fragile", "Religious"};
		
		Panel panel = new Panel();
		panel.setBackground(Color.LIGHT_GRAY);
		panel.setBounds(695, 69, 541, 348);
		contentPane.add(panel);
		panel.setLayout(null);
		
		//Confirm Details
		
		JLabel lblNewLabel = new JLabel("Parcel Delivery Details");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel.setBounds(10, 11, 278, 31);
		panel.add(lblNewLabel);
		
		JLabel lblCSenderName_1 = new JLabel("Sender Name");
		lblCSenderName_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblCSenderName_1.setBounds(10, 87, 142, 25);
		panel.add(lblCSenderName_1);
		
		JLabel lblCSenderName_2 = new JLabel("");
		lblCSenderName_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblCSenderName_2.setBounds(215, 87, 142, 25);
		
		JLabel lblCSenderAddress_1 = new JLabel("Sender Address");
		lblCSenderAddress_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblCSenderAddress_1.setBounds(10, 118, 142, 25);
		panel.add(lblCSenderAddress_1);
		
		JLabel lblCSenderAddress_2 = new JLabel("");
		lblCSenderAddress_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblCSenderAddress_2.setBounds(215, 118, 248, 25);
		
		
		JLabel lblSenderPhoneNumber_1 = new JLabel("Sender Phone Number");
		lblSenderPhoneNumber_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblSenderPhoneNumber_1.setBounds(10, 142, 220, 40);
		panel.add(lblSenderPhoneNumber_1);
		
		JLabel lblSenderPhoneNumber_2 = new JLabel("");
		lblSenderPhoneNumber_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblSenderPhoneNumber_2.setBounds(225, 142, 220, 40);
		
		JLabel lblReceiverName_1 = new JLabel("Receiver Name");
		lblReceiverName_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblReceiverName_1.setBounds(10, 201, 187, 40);
		panel.add(lblReceiverName_1);
		
		JLabel lblReceiverName_2 = new JLabel("");
		lblReceiverName_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblReceiverName_2.setBounds(233, 201, 187, 40);
		
		JLabel lblReceiverAddress_1 = new JLabel("Receiver Address");
		lblReceiverAddress_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblReceiverAddress_1.setBounds(10, 230, 187, 40);
		panel.add(lblReceiverAddress_1);
		
		JLabel lblReceiverAddress_2 = new JLabel("");
		lblReceiverAddress_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblReceiverAddress_2.setBounds(233, 230, 248, 40);
		
		JLabel lblReceiverPhoneNumber_1 = new JLabel("Receiver Phone Number");
		lblReceiverPhoneNumber_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblReceiverPhoneNumber_1.setBounds(10, 264, 230, 40);
		panel.add(lblReceiverPhoneNumber_1);
		
		JLabel lblReceiverPhoneNumber_2 = new JLabel("");
		lblReceiverPhoneNumber_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblReceiverPhoneNumber_2.setBounds(233, 264, 230, 40);
		
		Panel panel_1 = new Panel();
		panel_1.setBackground(Color.LIGHT_GRAY);
		panel_1.setBounds(695, 454, 440, 291);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblParcelInfo = new JLabel("Parcel Info");
		lblParcelInfo.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblParcelInfo.setBounds(10, 11, 193, 43);
		panel_1.add(lblParcelInfo);
		
		JLabel lblParcelId_1 = new JLabel("Parcel ID");
		lblParcelId_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblParcelId_1.setBounds(10, 76, 133, 40);
		panel_1.add(lblParcelId_1);
		
		lblParcelID_2 = new JLabel();
		lblParcelID_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblParcelID_2.setBounds(150, 76, 133, 40);
		panel_1.add(lblParcelID_2);
		
		JLabel lblParcelWeight_1 = new JLabel("Parcel Weight");
		lblParcelWeight_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblParcelWeight_1.setBounds(10, 127, 140, 40);
		panel_1.add(lblParcelWeight_1);
		
		JLabel lblParcelWeight_2 = new JLabel("");
		lblParcelWeight_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblParcelWeight_2.setBounds(150, 127, 140, 40);
		
		JLabel lblParcelType_1 = new JLabel("Parcel Type");
		lblParcelType_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblParcelType_1.setBounds(10, 178, 133, 40);
		panel_1.add(lblParcelType_1);
		
		JLabel lblParcelType_2 = new JLabel("");
		lblParcelType_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblParcelType_2.setBounds(150, 178, 133, 40);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(Color.LIGHT_GRAY);
		panel_2.setBounds(42, 69, 583, 553);
		contentPane.add(panel_2);
		panel_2.setLayout(null);
				
		
		tfParcelWeight = new JTextField();
		tfParcelWeight.setBounds(263, 39, 117, 31);
		panel_2.add(tfParcelWeight);
		tfParcelWeight.setEditable(false);
		tfParcelWeight.setFont(new Font("Tahoma", Font.PLAIN, 20));
		tfParcelWeight.setColumns(10);
		tfParcelWeight.setText(pweight);
		
		JLabel lblParcelWeight = new JLabel("Parcel Weight");
		lblParcelWeight.setBounds(21, 42, 123, 25);
		lblParcelWeight.setFont(new Font("Tahoma", Font.PLAIN, 20));
		panel_2.add(lblParcelWeight);
		
		JLabel lblParcelType = new JLabel("Parcel Type");
		lblParcelType.setBounds(21, 90, 104, 25);
		panel_2.add(lblParcelType);
		lblParcelType.setFont(new Font("Tahoma", Font.PLAIN, 20));
		JComboBox cbParcelType = new JComboBox(t1); 
		cbParcelType.setBounds(263, 87, 117, 31);
		panel_2.add(cbParcelType);
		cbParcelType.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		JLabel lblSenderName = new JLabel("Sender Name");
		lblSenderName.setBounds(21, 125, 187, 40);
		panel_2.add(lblSenderName);
		lblSenderName.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		tfSenderName = new JTextField();
		tfSenderName.setBounds(263, 129, 233, 33);
		panel_2.add(tfSenderName);
		tfSenderName.setFont(new Font("Tahoma", Font.PLAIN, 20));
		tfSenderName.setColumns(10);
		
		tfSenderAddress = new JTextField();
		tfSenderAddress.setBounds(263, 175, 233, 33);
		panel_2.add(tfSenderAddress);
		tfSenderAddress.setFont(new Font("Tahoma", Font.PLAIN, 20));
		tfSenderAddress.setColumns(10);
		
		JLabel lblSenderAddress = new JLabel("Sender Address");
		lblSenderAddress.setBounds(21, 171, 187, 40);
		panel_2.add(lblSenderAddress);
		lblSenderAddress.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		JLabel lblSenderPhoneNumber = new JLabel("Sender Phone Number");
		lblSenderPhoneNumber.setBounds(21, 218, 239, 40);
		panel_2.add(lblSenderPhoneNumber);
		lblSenderPhoneNumber.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		tfSenderPhone = new JTextField();
		tfSenderPhone.setBounds(263, 222, 233, 33);
		panel_2.add(tfSenderPhone);
		tfSenderPhone.setFont(new Font("Tahoma", Font.PLAIN, 20));
		tfSenderPhone.setColumns(10);
		
		JLabel lblReceiverName = new JLabel("Receiver Name");
		lblReceiverName.setBounds(21, 263, 187, 40);
		panel_2.add(lblReceiverName);
		lblReceiverName.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		tfReceiverName = new JTextField();
		tfReceiverName.setBounds(263, 267, 233, 33);
		panel_2.add(tfReceiverName);
		tfReceiverName.setFont(new Font("Tahoma", Font.PLAIN, 20));
		tfReceiverName.setColumns(10);
		
		tfReceiverAddress = new JTextField();
		tfReceiverAddress.setBounds(263, 313, 233, 33);
		panel_2.add(tfReceiverAddress);
		tfReceiverAddress.setFont(new Font("Tahoma", Font.PLAIN, 20));
		tfReceiverAddress.setColumns(10);
		
		tfReceiverPhone = new JTextField();
		tfReceiverPhone.setBounds(263, 361, 233, 33);
		panel_2.add(tfReceiverPhone);
		tfReceiverPhone.setFont(new Font("Tahoma", Font.PLAIN, 20));
		tfReceiverPhone.setColumns(10);
		
		JLabel lblReceiverPhoneNumber = new JLabel("Receiver Phone Number");
		lblReceiverPhoneNumber.setBounds(21, 357, 239, 40);
		panel_2.add(lblReceiverPhoneNumber);
		lblReceiverPhoneNumber.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		JLabel lblReceiverAddress = new JLabel("Receiver Address");
		lblReceiverAddress.setBounds(21, 309, 187, 40);
		panel_2.add(lblReceiverAddress);
		lblReceiverAddress.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		JLabel lblReceiverLocation = new JLabel("From");
		lblReceiverLocation.setBounds(21, 407, 55, 40);
		panel_2.add(lblReceiverLocation);
		lblReceiverLocation.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		tfPrice = new JTextField();
		tfPrice.setFont(new Font("Tahoma", Font.PLAIN, 14));
		tfPrice.setColumns(10);
		tfPrice.setBounds(360,490, 150, 28);
		tfPrice.setEditable(false);
		panel_2.add(tfPrice);
		
		JComboBox boxFrom = new JComboBox(new Object[]{});
		boxFrom.setModel(new DefaultComboBoxModel(new String[] {"Select From...","Peninsular State", "Within Peninsular", "Sabah & Sarawak"}));
		boxFrom.setFont(new Font("Tahoma", Font.PLAIN, 20));
		boxFrom.setBounds(85, 412, 175, 31);
		panel_2.add(boxFrom);
		
		JComboBox boxTo = new JComboBox(new Object[]{});
		boxTo.setModel(new DefaultComboBoxModel(new String[] {"Select To...","Peninsular State", "Within Peninsular", "Sabah & Sarawak"}));
		boxTo.setFont(new Font("Tahoma", Font.PLAIN, 20));
		boxTo.setBounds(314, 412, 182, 31);
		boxTo.addItemListener(new ItemListener(){

			@Override
			public void itemStateChanged(ItemEvent e) {
				 if(e.getStateChange() == ItemEvent.SELECTED) { 
			    	 String state = boxTo.getSelectedItem().toString();
			    	 calcRate(state);
			    	 
				 }
			}
			
		});
		panel_2.add(boxTo);
		
		JLabel lblTo = new JLabel("To");
		lblTo.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTo.setBounds(273, 407, 40, 40);
		panel_2.add(lblTo);
		
		JLabel lblPrice = new JLabel("Total Price :");
		lblPrice.setBounds(232, 476, 187, 54);
		panel_2.add(lblPrice);
		lblPrice.setFont(new Font("Tahoma", Font.PLAIN, 22));
		
		Button btnContinuePayment = new Button("Continue Payment");
		btnContinuePayment.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				PaymentFrame next = new PaymentFrame();
				next.setVisible(true);
			}
			
		});
		
		btnContinuePayment.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnContinuePayment.setBackground(Color.WHITE);
		btnContinuePayment.setBounds(210, 219, 223, 55);
		btnContinuePayment.setVisible(true);
		
		Button btnReset = new Button("RESET");
		btnReset.setBackground(Color.WHITE);
		btnReset.setActionCommand("Reset");
		btnReset.setBounds(21, 490, 118, 40);
		panel_2.add(btnReset);
		
		Button btnBack = new Button("BACK");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				ParcelKiosk ParcelKiosk;
				try {
					ParcelKiosk = new ParcelKiosk();
					ParcelKiosk.setVisible(true);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnBack.setBackground(Color.WHITE);
		btnBack.setActionCommand("Back");
		btnBack.setBounds(62, 657, 118, 40);
		contentPane.add(btnBack);
		
		Button btnConfirm = new Button("CONFIRM");
		btnConfirm.setBackground(Color.WHITE);
		btnConfirm.setActionCommand("Confirm");
		btnConfirm.setBounds(507, 657, 118, 40);
		contentPane.add(btnConfirm);
		
		//confirm panel
		
		
        panel_1.add(lblParcelType_2);
        panel_1.add(lblParcelWeight_2);
        panel.add(lblCSenderName_2);
        panel.add(lblCSenderAddress_2);
        panel.add(lblSenderPhoneNumber_2);
        panel.add(lblReceiverName_2);
        panel.add(lblReceiverAddress_2);
        panel.add(lblReceiverPhoneNumber_2);
		
        //end confirm panel
        
		btnConfirm.addActionListener (new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			
				if (cbParcelType.getSelectedItem().equals(0)) {
                    JOptionPane.showMessageDialog(null, "Please fill in Parcel Details properly");
				 } else if (tfSenderName.getText().toString().equals("")) {
	                    JOptionPane.showMessageDialog(null, "Please fill in Parcel Details properly");
				 } else if (tfSenderAddress.getText().toString().equals("")) {
	                    JOptionPane.showMessageDialog(null, "Please fill in Parcel Details properly");
				 } else if (tfSenderPhone.getText().toString().equals("")) {
	                    JOptionPane.showMessageDialog(null, "Please fill in Parcel Details properly");
				 } else if (tfReceiverName.getText().toString().equals("")) {
	                    JOptionPane.showMessageDialog(null, "Please fill in Parcel Details properly");
				 } else if (tfReceiverAddress.getText().toString().equals("")) {
	                    JOptionPane.showMessageDialog(null, "Please fill in Parcel Details properly");
				 } else if (tfReceiverPhone.getText().toString().equals("")) {
	                    JOptionPane.showMessageDialog(null, "Please fill in Parcel Details properly");
				 } else if (boxFrom.getSelectedItem().equals(0)) {
	                    JOptionPane.showMessageDialog(null, "Please fill in Parcel Details properly");
				 } else if (boxTo.getSelectedItem().equals(0)) {
	                    JOptionPane.showMessageDialog(null, "Please fill in Parcel Details properly");
	                    
				 } else {
					 
					 
					 try {
	                        
						 conn = (Connection)DriverManager.getConnection(connectionPath);
						 stmt = conn.createStatement();
                         
						 Socket socket = new Socket(InetAddress.getLocalHost(), 4228);
						 updateConnectionStatus(socket.isConnected());
						 
						 parcel.setParcwht(Double.parseDouble(tfParcelWeight.getText()));
						 cust.setSndname(tfSenderName.getText());
						 cust.setSndadd(tfSenderAddress.getText());
						 cust.setSndno(tfSenderPhone.getText());
						 cust.setSndsf(boxFrom.getSelectedItem().toString());
						 
						 
						 int i=1;  
						 String custID = "1000" + i++;;
						 
						 cust.setIdcust(Integer.parseInt(custID));
						 
						LocalDate mydate = LocalDate.now();
 				        String curr = mydate.toString();
 				        order.setOrdedate(curr);
 				        order.setRecname(tfReceiverName.getText());
 				        order.setRecadd(tfReceiverAddress.getText());
 				        order.setRecno(tfReceiverPhone.getText());
 				        order.setOrdstat("y");
 				        order.setOrdst(boxTo.getSelectedItem().toString());
 				        
 				        parcel.setParcwht(Double.parseDouble(tfParcelWeight.getText()));
 				        parcel.setParctype(cbParcelType.getSelectedItem().toString());
 				        String rate = tfPrice.getText();
 				        parcel.setParcdlrate(rate);
 				        parcelTrans.setTransamount(tfPrice.getText());
 				        System.out.println(parcel.getParcdlrate());
 				        double weight = Double.parseDouble(tfParcelWeight.getText());
 				        
 				       ObjectOutputStream oos = new ObjectOutputStream (socket.getOutputStream());
 				       oos.writeObject(parcel);
                   	
 				       System.out.println("Computing Parcel Weight= "+ parcel.getParcwht() + " KG"
           					+ " to the server-side");
 				       
 				      ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
 				      AppParcel incParcel = (AppParcel) ois.readObject();
                  	
 				      System.out.println("Weight of the parcel(in KG): "+incParcel.getParcwht());
 				      
 				      cust = new appCustomer(Integer.parseInt(custID), tfSenderName.getText(), tfSenderAddress.getText(),
 				    		  tfSenderPhone.getText(),boxFrom.getSelectedItem().toString()); 				      
                    
                    JOptionPane.showMessageDialog(null, "The parcel information has been recorded into the system.");
                    
                    String parcelID = parcelIDGen.getParcelID();
                    updateServerParcel (": " + parcelID);
                    lblParcelType_2.setText(": " + cbParcelType.getSelectedItem().toString());
                    lblParcelWeight_2.setText(": " + tfParcelWeight.getText() + "  KG");
                    lblCSenderName_2.setText(": " + tfSenderName.getText());
                    lblCSenderAddress_2.setText(": " + tfSenderAddress.getText());
                    lblSenderPhoneNumber_2.setText(": " + tfSenderPhone.getText());                    
                    lblReceiverName_2.setText(": " + tfReceiverName.getText());
                    lblReceiverAddress_2.setText(": " + tfReceiverAddress.getText());
                    lblReceiverPhoneNumber_2.setText(": " + tfReceiverPhone.getText());
                    
                    panel_1.add(btnContinuePayment);
                    
                    socket.close();
 				        				        
				     			       
					 } catch (Exception ex) {
                         System.err.println("Exception: " + ex.getMessage());
                     }
                     try {
                         if (stmt != null) {
                             stmt.close();
                             conn.close();
                         }
                     } catch (SQLException ex) {
                         System.out.println(ex.getMessage());
                         ex.printStackTrace();
                     }

                     
			}
		}
	});

}



	protected void calcRate(String state) {
		// TODO Auto-generated method stub
		Random random = new Random();
		double total = random.nextDouble();			
		Double tfPriceDouble  = pmng.parcCharge(total,state);
		String amountpaid = Double.toString(tfPriceDouble);
		parcel.setParcdlrate(amountpaid);
		tfPrice.setText("RM  " + amountpaid);
		 
	}
	
	private void updateConnectionStatus(boolean connected) {
		
		
		String status = "No connection to server.";
		
		if (connected)
			status = "Connection has established.";
		
			System.out.println(status);

}
	
	protected void updateServerParcel(String parcelID) {
		// TODO Auto-generated method stub
		 lblParcelID_2.setText(parcelID);
		
	}
}
