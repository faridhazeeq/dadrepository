package Parcel;

public class AppParcelMnger {
	
	public AppParcel createParcel(AppParcel parcel) {
		
		double dlweight = parcel.getParcwht();
		parcel.setParcwht(dlweight);
		
		String dlrate = parcel.getParcdlrate();
		parcel.setParcdlrate(dlrate);
		
		double AmountParcel = this.parcCharge(parcel.getParcwht(),parcel.getParcdlrate());
		String totalAmount = Double.toString(AmountParcel);
		parcel.setParcdlrate(totalAmount);
		
		return parcel;
		
	}

	public double parcCharge(double dlweight, String dlrate) {
	double AmountParcel = 0.0;
	
//	System.out.println(dlweight);
//	System.out.println("\nWeight of the parcel(in kg): "+(dlrate));
		
		if(dlrate == "Peninsular State") {
			
			if(dlweight >= 0.0 && dlweight <= 0.5) {
				AmountParcel = 8.0;				
			}
			else if (dlweight >= 0.51 && dlweight <= 1.00) {
				AmountParcel = 9.0;
			}
			else if (dlweight >= 1.01 && dlweight <= 1.50) {
				AmountParcel = 10.05;
			}
			else if (dlweight >= 1.51 && dlweight <= 2.00) {
				AmountParcel = 10.60;
			}
			else if (dlweight >= 2.01 && dlweight <= 2.50) {
				AmountParcel = 11.65;
			}
			else if (dlweight >= 2.51 && dlweight <= 3.00) {
				AmountParcel = 12.70;
			}
			else if (dlweight >= 3.01 && dlweight <= 3.50) {
				AmountParcel = 13.80;
			}
			else if (dlweight >= 3.51 && dlweight <= 4.00) {
				AmountParcel = 14.30;
			}
			else if (dlweight >= 4.01 && dlweight <= 4.50) {
				AmountParcel = 14.85;
			}
			else if (dlweight >= 4.51 && dlweight <= 5.00) {
				AmountParcel = 14.85;
			}
			else if (dlweight >= 5.01 && dlweight <= 5.50) {
				AmountParcel = 15.90;
			}
			else if (dlweight >= 5.51 && dlweight <= 6.00) {
				AmountParcel = 15.90;
			}
			else if (dlweight >= 6.01 && dlweight <= 6.50) {
				AmountParcel = 16.95;
			}
			else if (dlweight >= 6.51 && dlweight <= 7.00) {
				AmountParcel = 16.95;
			}
			else if (dlweight >= 7.01 && dlweight <= 7.50) {
				AmountParcel = 18;
			}
			else if (dlweight >= 7.51 && dlweight <= 8.00) {
				AmountParcel = 18;
			}
			else if (dlweight >= 8.01 && dlweight <= 8.50) {
				AmountParcel = 20.15;
			}
			else if (dlweight >= 8.51 && dlweight <= 9.00) {
				AmountParcel = 20.15;
			}
			else if (dlweight >= 9.01 && dlweight <= 9.50) {
				AmountParcel = 21.20;
			}
			else if (dlweight >= 9.51 && dlweight <= 10.00) {
				AmountParcel = 21.20;
			}
		}		
		else if(dlrate == "Within Peninsular") {									
			
			if(dlweight >= 0.0 && dlweight <= 0.50) {			
				AmountParcel = 8.50;
			}	
			else if (dlweight >= 0.51 && dlweight <= 1.00) {
				AmountParcel = 10.05;
			}
			else if (dlweight >= 1.01 && dlweight <= 1.50) {
				AmountParcel = 11.15;
			}
			else if (dlweight >= 1.51 && dlweight <= 2.00) {
				AmountParcel = 12.20;
			}
			else if (dlweight >= 2.01 && dlweight <= 2.50) {
				AmountParcel = 15.15;
			}
			else if (dlweight >= 2.51 && dlweight <= 3.00) {
				AmountParcel = 16.90;
			}
			else if (dlweight >= 3.01 && dlweight <= 3.50) {
				AmountParcel = 18.65;
			}
			else if (dlweight >= 3.51 && dlweight <= 4.00) {
				AmountParcel = 20.40;
			}
			else if (dlweight >= 4.01 && dlweight <= 4.50) {
				AmountParcel = 22.15;
			}
			else if (dlweight >= 4.51 && dlweight <= 5.00) {
				AmountParcel = 23.30;
			}
			else if (dlweight >= 5.01 && dlweight <= 5.50) {
				AmountParcel = 24.50;
			}
			else if (dlweight >= 5.51 && dlweight <= 6.00) {
				AmountParcel = 25.65;
			}
			else if (dlweight >= 6.01 && dlweight <= 6.50) {
				AmountParcel = 26.80;
			}
			else if (dlweight >= 6.51 && dlweight <= 7.00) {
				AmountParcel = 28.00;
			}
			else if (dlweight >= 7.01 && dlweight <= 7.50) {
				AmountParcel = 29.16;
			}
			else if (dlweight >= 7.51 && dlweight <= 8.00) {
				AmountParcel = 30.30;
			}
			else if (dlweight >= 8.01 && dlweight <= 8.50) {
				AmountParcel = 31.50;
			}
			else if (dlweight >= 8.51 && dlweight <= 9.00) {
				AmountParcel = 32.65;
			}
			else if (dlweight >= 9.01 && dlweight <= 9.50) {
				AmountParcel = 33.80;
			}
			else if (dlweight >= 9.51 && dlweight <= 10.00) {
				AmountParcel = 35.00;
			}			
		}
		
		else if(dlrate == "Sabah & Sarawak") {			
			
			if(dlweight >= 0.0 && dlweight <= 0.50) {			
				AmountParcel = 14.85;
			}		
			else if (dlweight >= 0.51 && dlweight <= 1.00) {
				AmountParcel = 21.20;
			}
			else if (dlweight >= 1.01 && dlweight <= 1.50) {
				AmountParcel = 27.55;
			}
			else if (dlweight >= 1.51 && dlweight <= 2.00) {
				AmountParcel = 33.90;
			}
			else if (dlweight >= 2.01 && dlweight <= 2.50) {
				AmountParcel = 40.30;
			}
			else if (dlweight >= 2.51 && dlweight <= 3.00) {
				AmountParcel = 46.65;
			}
			else if (dlweight >= 3.01 && dlweight <= 3.50) {
				AmountParcel = 53.00;
			}
			else if (dlweight >= 3.51 && dlweight <= 4.00) {
				AmountParcel = 59.35;
			}
			else if (dlweight >= 4.01 && dlweight <= 4.50) {
				AmountParcel = 65.70;
			}
			else if (dlweight >= 4.51 && dlweight <= 5.00) {
				AmountParcel = 72.10;
			}
			else if (dlweight >= 5.01 && dlweight <= 5.50) {
				AmountParcel = 78.45;
			}
			else if (dlweight >= 5.51 && dlweight <= 6.00) {
				AmountParcel = 84.80;
			}
			else if (dlweight >= 6.01 && dlweight <= 6.50) {
				AmountParcel = 91.15;
			}
			else if (dlweight >= 6.51 && dlweight <= 7.00) {
				AmountParcel = 97.50;
			}
			else if (dlweight >= 7.01 && dlweight <= 7.50) {
				AmountParcel = 103.90;
			}
			else if (dlweight >= 7.51 && dlweight <= 8.00) {
				AmountParcel = 110.25;
			}
			else if (dlweight >= 8.01 && dlweight <= 8.50) {
				AmountParcel = 116.60;
			}
			else if (dlweight >= 8.51 && dlweight <= 9.00) {
				AmountParcel = 122.95;
			}
			else if (dlweight >= 9.01 && dlweight <= 9.50) {
				AmountParcel = 129.30;
			}
			else if (dlweight >= 9.51 && dlweight <= 10.00) {
				AmountParcel = 135.70;
			}
		}
		 
		else {
			System.out.println("Error! Parcel Manager");
		}
		
//		System.out.println(dlweight);
//		System.out.println("\nWeight of the parcel(in kg): "+(dlrate));
//		System.out.println("\nAmount in RM of the parcel(in RM): "+(AmountParcel));
		return AmountParcel;
	}

}
