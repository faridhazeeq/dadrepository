package Transaction;

import java.io.Serializable;

import Order.AppOrder;

public class AppTransaction implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public int transID;
	public String transdate;
	public String transamount;
	public String refNo;
	public boolean transstat;
	public String cc;
	public int cvv;
	
	public AppTransaction() {
		
	}

	public AppTransaction(int transID, String transdate, String transamount, boolean transstat, String cc,
			int cvv, String refNo) {
		super();
		this.transID = transID;
		this.transdate = transdate;
		this.transamount = transamount;
		this.refNo = refNo;
		this.transstat = transstat;
		this.cc = cc;
		this.cvv = cvv;
	}

	public AppOrder order;
	
	public AppOrder getOrder() {
		return order;
		
	}
	
	public void setOrder(AppOrder order) {
		this.order = order;
		
	}

	public int getTransID() {
		return transID;
	}

	public void setTransID(int transID) {
		this.transID = transID;
	}

	public String getTransdate() {
		return transdate;
	}

	public void setTransdate(String transdate) {
		this.transdate = transdate;
	}

	public String getTransAmount() {
		return transamount;
	}

	public void setTransamount(String transamount) {
		this.transamount = transamount;
	}

	public String getRefNo() {
		return refNo;
	}

	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}

	public boolean isTransstat() {
		return transstat;
	}

	public void setTransstat(boolean transstat) {
		this.transstat = transstat;
	}

	public String getCc() {
		return cc;
	}

	public void setCc(String cc) {
		this.cc = cc;
	}

	public int getCvv() {
		return cvv;
	}

	public void setCvv(int cvv) {
		this.cvv = cvv;
	}
	
	

}
