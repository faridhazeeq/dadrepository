package Server;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Vector;

import Customer.appCustomer;
import Order.AppOrder;
import Parcel.AppParcel;
import Parcel.AppParcelDGen;
import Parcel.AppParcelMnger;


public class AppServer extends Thread {
	
	static Vector records = new Vector(10,10);
    ObjectOutputStream out =null;
    
    static String databaseName = "parceldad";
	static String username = "root";
	static String password = "123456";
    static Connection conn = null;
    static java.sql.Statement stmt = null;
    static ResultSet rs;
    static String connectionPath = "jdbc:mysql://localhost:3306/" + databaseName + "?" +
            "user=" + username + "&password=" + password;
    appCustomer cust = null;
    AppOrder order = null;
    AppParcel parcel = null;
    
    
    public static void main(String[] args) {
    	
    	AppParcelMnger parcelManager = new AppParcelMnger();
    	
    	AppServerJFrame serverJFrame = new AppServerJFrame();
		serverJFrame.setVisible(true);
    	
		try {
			
			int portNo = 4228;
			ServerSocket serverSocket = new ServerSocket(portNo);

			AppParcelDGen parcelIDGenerator = new AppParcelDGen();

			int totalReq = 0;

			while (true) {

				Socket clientSocket = serverSocket.accept();
				
				String parcelid = parcelIDGenerator.getParcelID();
				
				ObjectInputStream ois = new ObjectInputStream(clientSocket.getInputStream());
				AppParcel parcel = (AppParcel) ois.readObject();
				parcel = parcelManager.createParcel(parcel);
				
				ObjectOutputStream oos = new ObjectOutputStream(clientSocket.getOutputStream());
				oos.writeObject(parcel);
				
				
				serverJFrame.updateRequestStatus("Parcel Weight: "+ parcel.getParcwht() + "KG");
				serverJFrame.updateRequestStatus("Parcel ID: " + parcelid);
				serverJFrame.updateRequestStatus("Connection accepted from the client.  " + "Total request =" + ++totalReq);
			    serverJFrame.updateRequestStatus("Data sent: ");
			         
			}


			
			
		} catch (Exception exception) {

			System.out.println("Server App Error detected!");
			exception.printStackTrace();

		}
	
	}
    	
    }




