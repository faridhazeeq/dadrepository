package Server;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class AppServerJFrame extends JFrame{

	private static final long serialVersionUID = 1L;

		private JLabel lblSvrStatus;
		private JTextArea txtReqStatus;
		
		private int width = 800;
		private int height = 600;

		//constructor for the class
		public AppServerJFrame () {
			
			this.setLayout(new BorderLayout());
			this.setTitle("Parcel Kiosk App: Server Side For Parcel");
			this.setSize(new Dimension(width, height));  
			
			this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			
	        this.setLocationRelativeTo(null);
	 
			this.lblSvrStatus = new JLabel ("-");			
			this.txtReqStatus  = new JTextArea(20, 70);
			
			loadComponent();
					
		}
		
		private JPanel getSvrStatusPanel(Font font) {
			
			// Components to display server's status
			JPanel panel = new JPanel();
			JLabel lblServer = new JLabel ("Server status is: ");
			
			// Style the components
			lblServer.setFont(font);
			lblSvrStatus.setFont(font);
			lblServer.setBackground(Color.WHITE);
			lblServer.setOpaque(true);
			lblSvrStatus.setBackground(Color.WHITE);
			lblSvrStatus.setOpaque(true);

			// Organize component into the panel
			panel.add(lblServer);
			panel.add(lblSvrStatus);
			
			return panel;
			
		}
		
		private JPanel getReqStatusPanel () {
			
			// Component to display request's status
			JPanel panel = new JPanel();

			// Set default message when the frame launch for the first time
			txtReqStatus.setText("\n > Server is running");
			txtReqStatus.setEditable(false);
			
			// Styling the request text
			txtReqStatus.setFont(new Font("Courier", Font.PLAIN, 15));


			// Add component to panel
			panel.add(txtReqStatus);
			
			return panel;
			
		}
		
		public void loadComponent() {
			
			// Get the server status panel and add to frame
			Font font = this.getFontStyle();
			JPanel topPanel = this.getSvrStatusPanel(font);
			this.add(topPanel, BorderLayout.NORTH);
			
			
			// Component to display request's status
			JPanel centrePanel = this.getReqStatusPanel();		
			this.add(centrePanel, BorderLayout.CENTER);			
		}
		
		public void updateServerStatus(boolean flag) {
			
			String status = "Waiting for connection.";
			
			if (flag)
				status = "Received connection";
			
			this.lblSvrStatus.setText(status);			
		}
				
		public void updateRequestStatus (String status) {

			String currentText = this.txtReqStatus.getText();
			txtReqStatus.setEditable(true);

			status += "\n > " + currentText;
			this.txtReqStatus.setText(status);
			txtReqStatus.setEditable(false);
		}

		
		private Font getFontStyle() {
			
			Font font = new Font (Font.SANS_SERIF, Font.PLAIN, 30);
			
			return font;
			
		}

}
