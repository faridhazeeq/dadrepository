package TransFrame;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Panel;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.awt.Button;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.MatteBorder;
import javax.swing.border.TitledBorder;
import javax.swing.JTabbedPane;
import Customer.appCustomer;

import Order.AppOrder;
import Parcel.AppParcel;
import Parcel.AppParcelMnger;
import Transaction.AppTransaction;


public class PaymentFrame extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JLabel exc;
	private JTextField tfCard;
	private JTextField tfCardName;
	private JTextField tfAmount;
	private boolean statusT;
	String track;
	

	String databaseName = "parceldad";
	String username = "root";
	String password = "123456";
    Connection conn;
    java.sql.Statement stmt;
    ResultSet st;
    String connectionPath = "jdbc:mysql://localhost:3306/" + databaseName + "?" +
            "user=" + username + "&password=" + password;

	
	AppTransaction parcelTransaction = new AppTransaction();
	AppParcel parcel = new AppParcel();
	appCustomer customer = new appCustomer();
	AppOrder order = new AppOrder();
	AppParcelMnger pm = new AppParcelMnger();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PaymentFrame frame = new PaymentFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public PaymentFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 911, 689);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Parcel Ordering System");
		lblNewLabel.setBounds(332, 11, 227, 25);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		contentPane.add(lblNewLabel);
		
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(10, 47, 877, 594);
		contentPane.add(tabbedPane);
		
		JPanel panel = new JPanel();
		tabbedPane.addTab("Payment ", null, panel, null);
		panel.setLayout(null);
		
		exc = new JLabel("");
		exc.setBounds(10, 304, 359, 14);
		exc.setFont(new Font("Tahoma", Font.PLAIN, 18));
		exc.setForeground(Color.RED);
    	exc.setVisible(false);
		panel.add(exc);
		
		JLabel lblCardNumber = new JLabel("Card Number");
		lblCardNumber.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblCardNumber.setBounds(10, 11, 231, 14);
		panel.add(lblCardNumber);
		
		tfCard = new JTextField();
		tfCard.setBounds(10, 36, 852, 33);
		panel.add(tfCard);
		tfCard.setColumns(10);
		
		JLabel lblValid = new JLabel("Valid Through");
		lblValid.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblValid.setBounds(10, 149, 231, 22);
		panel.add(lblValid);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setFont(new Font("Tahoma", Font.PLAIN, 20));
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Year", "2022", "2023", "2024", "2025", "2026", "2027", "2028", "2029", "2030"}));
		comboBox.setSelectedIndex(0);
		comboBox.setBounds(146, 182, 105, 33);
		panel.add(comboBox);
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"Month", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"}));
		comboBox_1.setSelectedIndex(0);
		comboBox_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		comboBox_1.setBounds(10, 182, 105, 33);
		panel.add(comboBox_1);
		
		JLabel lblCardName = new JLabel("Name On Card");
		lblCardName.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblCardName.setBounds(10, 80, 231, 14);
		panel.add(lblCardName);
		
		tfCardName = new JTextField();
		tfCardName.setColumns(10);
		tfCardName.setBounds(10, 105, 852, 33);
		panel.add(tfCardName);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("CVV Number");
		lblNewLabel_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1_1_1.setBounds(363, 156, 231, 22);
		panel.add(lblNewLabel_1_1_1);
		
		JTextField tfCVV = new JTextField();
		tfCVV.setBounds(362, 186, 500, 33);
		tfCVV.setColumns(10);
		panel.add(tfCVV);
		
		JLabel lblNewLabel_1_2_1 = new JLabel("Total Amount");
		lblNewLabel_1_2_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1_2_1.setBounds(10, 231, 231, 14);
		panel.add(lblNewLabel_1_2_1);
		
		tfAmount = new JTextField();
		tfAmount.setEditable(false);
		tfAmount.setColumns(10);
		String portamount= Kiosk.ManageParcel.tfPrice.getText();
		tfAmount.setText(portamount);
		tfAmount.setBounds(10, 256, 852, 33);
		panel.add(tfAmount);
		
		
		JButton btnBack = new JButton("Back");
		btnBack.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnBack.setBounds(10, 497, 168, 58);
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "Transaction cancelled. You may close the payment window now.");
				dispose();
			}

		});
		panel.add(btnBack);
		
		JPanel panel_1 = new JPanel();
		tabbedPane.addTab("Receipt", null, panel_1, null);
		panel_1.setLayout(null);
		
		JLabel lblTransactionStatus = new JLabel("Transaction Status");
		lblTransactionStatus.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblTransactionStatus.setBounds(299, 11, 301, 33);
		panel_1.add(lblTransactionStatus);
		
		JLabel lblStatus = new JLabel("Status");
		lblStatus.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblStatus.setBounds(10, 77, 154, 33);
		panel_1.add(lblStatus);
		
		JLabel lblDatetime = new JLabel("Date/Time");
		lblDatetime.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblDatetime.setBounds(10, 114, 193, 33);
		panel_1.add(lblDatetime);
		
		JLabel lblReferenceNumber = new JLabel("Reference Number");
		lblReferenceNumber.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblReferenceNumber.setBounds(10, 152, 193, 33);
		panel_1.add(lblReferenceNumber);
		
		JLabel lblPaymentAmount = new JLabel("Payment Amount");
		lblPaymentAmount.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblPaymentAmount.setBounds(10, 184, 193, 33);
		panel_1.add(lblPaymentAmount);
		
		JLabel lblBank = new JLabel("Bank");
		lblBank.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblBank.setBounds(10, 220, 193, 33);
		panel_1.add(lblBank);
		
		JLabel lblDeliveryInfo = new JLabel("Delivery Info");
		lblDeliveryInfo.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblDeliveryInfo.setBounds(299, 264, 181, 33);
		panel_1.add(lblDeliveryInfo);
		
		JLabel lblTrackingNumber = new JLabel("Tracking Number");
		lblTrackingNumber.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTrackingNumber.setBounds(10, 303, 193, 33);
		panel_1.add(lblTrackingNumber);
		
		JButton btnReceipt = new JButton("Print");
		btnReceipt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
				//take transaction id and order id as file name 
				String target = parcelTransaction.getRefNo() + ".txt";
				
				Receipt printed = new Receipt();
				String receiptContent = Receipt.receiptPayment(parcelTransaction);
				FileWriter fileWriter = new FileWriter (target);
				fileWriter.write(receiptContent);
				fileWriter.flush();
				fileWriter.close();	
				
				} catch (Exception ex) {
					
                    System.err.println("SQLException: " + ex.getMessage());
                    
                }
				
			}
		});
		btnReceipt.setBounds(10, 507, 852, 48);
		panel_1.add(btnReceipt);
		
		JLabel lblNewLabel_2 = new JLabel(" :");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_2.setBounds(192, 77, 38, 33);
		panel_1.add(lblNewLabel_2);
		
		JLabel lblNewLabel_2_1 = new JLabel(" :");
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_2_1.setBounds(192, 114, 38, 33);
		panel_1.add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_2_2 = new JLabel(" :");
		lblNewLabel_2_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_2_2.setBounds(192, 152, 38, 33);
		panel_1.add(lblNewLabel_2_2);
		
		JLabel lblNewLabel_2_3 = new JLabel(" :");
		lblNewLabel_2_3.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_2_3.setBounds(192, 184, 38, 33);
		panel_1.add(lblNewLabel_2_3);
		
		JLabel lblNewLabel_2_4 = new JLabel(" :");
		lblNewLabel_2_4.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_2_4.setBounds(192, 220, 38, 33);
		panel_1.add(lblNewLabel_2_4);
		
		JLabel lblNewLabel_2_5 = new JLabel(" :");
		lblNewLabel_2_5.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_2_5.setBounds(192, 303, 38, 33);
		panel_1.add(lblNewLabel_2_5);
		
		JLabel lblStatus_1 = new JLabel("");
		lblStatus_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblStatus_1.setBounds(213, 77, 154, 33);
		panel_1.add(lblStatus_1);
		
		JLabel lblDatetime_1 = new JLabel("");
		lblDatetime_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblDatetime_1.setBounds(213, 114, 193, 33);
		panel_1.add(lblDatetime_1);
		
		JLabel lblReferenceNumber_1 = new JLabel("");
		lblReferenceNumber_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblReferenceNumber_1.setBounds(213, 152, 193, 33);
		panel_1.add(lblReferenceNumber_1);
		
		JLabel lblPaymentAmount_1 = new JLabel("");
		lblPaymentAmount_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblPaymentAmount_1.setBounds(213, 184, 193, 33);
		panel_1.add(lblPaymentAmount_1);
		
		JLabel lblBank_1 = new JLabel("");
		lblBank_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblBank_1.setBounds(213, 220, 193, 33);
		panel_1.add(lblBank_1);
		
		JLabel lblTrackingNumber_1 = new JLabel("");
		lblTrackingNumber_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTrackingNumber_1.setBounds(213, 303, 193, 33);
		panel_1.add(lblTrackingNumber_1);
		
		JButton btnProceed = new JButton("Proceed");
		btnProceed.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnProceed.setBounds(694, 497, 168, 58);
		panel.add(btnProceed);
		btnProceed.addActionListener(new ActionListener( ) {
			//private AppTransaction parcelTransaction;

			public void actionPerformed(ActionEvent e)	{
				
			try {
				String cardno = tfCard.getText();
				System.out.println(cardno);
				System.out.println(cardno.length());
				
				if(cardno.length() == 16)
		        {                                
					tfCard.setText(cardno);
		            
		            try
					{    
			        
			        	conn = (Connection)DriverManager.getConnection(connectionPath);
                        stmt = conn.createStatement();

		            	Socket c = new Socket(InetAddress.getLocalHost(), 4884);
		            	
		            	updateConnectionStatus(c.isConnected());
		            	
		            	parcelTransaction.setTransamount(tfAmount.getText());
						parcelTransaction.setCc(cardno);				

						ObjectOutputStream dout = new ObjectOutputStream(c.getOutputStream());
						dout.writeObject(parcelTransaction);

						System.out.println("Sending "+ parcelTransaction.getCc() + ""
	        					+ " to server-side application");
						 

		            	ObjectInputStream ois = new ObjectInputStream(c.getInputStream());
		            	AppTransaction processedParcelTransaction = (AppTransaction) ois.readObject();
		
		    			System.out.println("Total Amount RM: "+ processedParcelTransaction.getTransAmount());

		            	parcelTransaction.setCvv(Integer.parseInt(tfCVV.getText()));
		            	
		            	int i=1;  
						
						String payment_id = "1000" + i++;;
						
						parcelTransaction.setTransID(Integer.parseInt(payment_id));
		            	track = parcelTransaction.getTransdate() + "00" + payment_id;
		            	
		            	System.out.println(track);
		            	
		            	LocalDate mycurrdate = LocalDate.now();
		            	String current = mycurrdate.toString();
						DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/YYYY");
				        String localDate = formatter.format(mycurrdate);
				        
				        DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("ddMMYYYY");
				        String localDate2 = formatter2.format(mycurrdate);
				        
				        String ref = localDate2 + "1337" + parcelTransaction.getTransID();
				        
				        parcelTransaction.setRefNo(ref);
				        
				        parcelTransaction = new AppTransaction(Integer.parseInt(payment_id), current, tfAmount.getText(), true,
		        				cardno,Integer.parseInt(tfCVV.getText()), ref);
				        		            	
						 parcel.setParcno("MY" + localDate2);
						 
						System.out.println("Client = Successful");
						JOptionPane.showMessageDialog(null, "Transaction successful please proceed to receipt.");
						
						
						lblStatus_1.setText("Successful");			        
						lblDatetime_1.setText(localDate);
						lblReferenceNumber_1.setText(ref);
						lblBank_1.setText("CIMB Bank Berhad");
						lblTrackingNumber_1.setText("MYS" + localDate2 + "PKG");
						lblPaymentAmount_1.setText(parcelTransaction.getTransAmount());						
//						dispose(); 
						
						
						//OrderFrame of = new OrderFrame();
						//of.setVisible(true);
						c.close();
						
					}catch (Exception ex) {
	                    System.err.println("SQLException: " + ex.getMessage());
	                }
				        
				        }
				        else
				        {
				        	exc.setVisible(true);
				        	exc.setText("Fail to authenticate the credit card");
				        	tfCard.setText("");
				        }
					} catch (Exception ex) {
						
	                    System.err.println("SQLException: " + ex.getMessage());
	                    
	                }
				
				}
			
			public String getCardCredit() throws InterruptedException {

				waitForInput();
				return tfCard.getText();
			}

			public void setCardCredit() {
				tfCard.getText();
			}

		    public void waitForInput() throws InterruptedException {
		        synchronized(this) {
		            wait();
		        }
		    }

		    public void release() throws InterruptedException {
		        synchronized(this) {
		            notifyAll();
		        }
		    }
		    
		    public AppTransaction getOrderTransaction() {
		    	return parcelTransaction;
		    }

			public void setStatus(boolean status) {
				statusT = status;
			}

			private void updateConnectionStatus(boolean connected) {

				String status = "No connection to server.";
				
				if (connected)
					status = "Connection has established.";
				
					System.out.println(status);
				
			}

			});
			}
}
